module.exports = {
  prefix: "e!",
  owner: "305360816251600898",
  token: "BOT Tokeni",
}