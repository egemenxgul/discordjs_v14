const Discord = require("discord.js");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const { SlashCommandBuilder } = require("@discordjs/builders");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("istatistik")
    .setDescription("Botun istatistiklerini gösterir."),
  run: async (client, message, args) => {
    const Uptime = moment
      .duration(client.uptime)
      .format(" D [gün], H [saat], m [dakika], s [saniye]");
    const embed = new EmbedBuilder()
      .setAuthor({
        name: "Bot İstatistik",
        iconURL: client.user.avatarURL(),
      })
      .setDescription(
        `👑 Sahip ve Geliştirici: <@305360816251600898> (Egemen#0001)
  
  📊 Toplam Kullanıcı: **${client.users.cache.size.toLocaleString()}**
  📊 Toplam Sunucu: **${client.guilds.cache.size.toLocaleString()}**
  📊 Toplam Kanal: **${client.channels.cache.size.toLocaleString()}**
  
  📊 Hafıza Kullanımı: **${(
          process.memoryUsage().heapUsed /
          1024 /
          512
        ).toFixed(2)}Mb**
  📊 Uptime: **${Uptime}**
  📊 Gecikme: **${client.ws.ping}**
  
  📊 NodeJS Sürümü: **${process.version}**
  📊 DiscordJS Sürümü: **${Discord.version}**`
      )
      .setFooter({
        text: `Bot İstatistik`,
        iconURL: message.member.displayAvatarURL({ dynamic: true }),
      })
      .setColor("Blurple");
    message.reply({ embeds: [embed] });
  }
}; 