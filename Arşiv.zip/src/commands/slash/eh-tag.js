const Discord = require("discord.js");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const { SlashCommandBuilder } = require("@discordjs/builders");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("tag")
    .setDescription("discord.gg/egemen tagını gösterir."),
  run: async (client, message, args) => {
    const embed = new EmbedBuilder()
      .setAuthor({
        name: "discord.gg/egemen",
        iconURL: client.user.avatarURL(),
      })
      .setDescription(
        '**Tag:** `ℨ`  **Sunucu:** discord.gg/egemen'
      )
      .setFooter({
        text: `discord.gg/egemen`,
        iconURL: message.member.displayAvatarURL({ dynamic: true }),
      })
      .setColor("Blurple");
    message.reply({ embeds: [embed] });
  }
};