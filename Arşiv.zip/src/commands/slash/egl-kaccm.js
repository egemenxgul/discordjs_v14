const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const { SlashCommandBuilder } = require("@discordjs/builders");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kaçcm")
    .setDescription("Ek bacağınızın kaç cm olduğunu söyler."),
  run: async (client, interaction) => {

    const cm = Math.floor(Math.random(100) * 100);

    const embed = new EmbedBuilder()
      .setDescription(`Senin ek bacak ${cm} cm çıktı`)
      .setColor("#0082ff");
    interaction.reply({ embeds: [embed] });

  }
}
