const { EmbedBuilder } = require("discord.js");
const db = require("croxydb");
module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['destek-yetkili', "ticket-yetkili"],
  permLevel: 0,
  name: 'destek-yetkilisi',
  description: 'destek-yetkilisi',
  usage: 'destek-yetkilisi',
  cooldown: 5000,
  run: async (client, message, args) => {
  let channel = message.mentions.roles.first();
  if (!channel) return message.reply("Lütfen bir rol etiketle");
  message.reply(
    "Başarıyla destek ekibi rolü <@&" + channel + "> olarak ayarlandı!"
  );
  db.set(`ticketmod_${message.guild.id}`, channel.id);
}
}
