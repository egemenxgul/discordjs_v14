const { EmbedBuilder } = require('discord.js')
const moment = require('moment')
moment.locale('TR')

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ["kb", "kullanici-bilgi", "kullanıcıbilgi"],
  permLevel: 0,
  name: 'kullanıcı-bilgi',
  description: 'kb',
  usage: 'kb',
  cooldown: 5000,
  run: (client, message, args) => {

        const member = message.mentions.members.first() || message.member
        const status = {
            online: '🟢 Çevrimiçi',
            idle: '🟡 Klavyeden Uzakta',
            dnd: '🔴 Rahatsız Etmeyin',
            offline: '⚫ Çevrimdışı'
        }
const embed = new EmbedBuilder()
.setTitle("EgoBot - Kullanıcı Bilgi")
.setDescription(`**Kullanıcı Adı:** ${member.user.username}\n**Kullanıcı ID:** ${member.id}\n**Durum:** ${status[member.presence.status]}\n**Hesap Oluşturulma Tarihi:** ${moment.utc(member.user.createdAt).format('LLLL')}\n**Sunucuya Katılım Tarihi:** ${moment.utc(member.joinedAt).format('LLLL')}\n**Rolleri:** ${member.roles.cache.map(role => role.toString())}`)
.setColor("Random")
        
        message.channel.send({embeds: [embed]})
    }
}
