const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
  name: 'avatar',
  description: 'avatar',
  usage: 'avatar',
  cooldown: 5000,
  run: async (client, message, args) => {
let membro = message.mentions.members.first() || client.users.cache.get(args[0]) || message.author;
let avatarURL = membro.displayAvatarURL({size: 2048, dynamic: true})

const row = new ActionRowBuilder()
.addComponents(
  new ButtonBuilder()
  .setLabel('Avatar Link')
  .setEmoji('🔗')
  .setStyle(ButtonStyle.Link)
  .setURL(avatarURL)
)

let embed = new EmbedBuilder()
.setAuthor({ name: message.author.tag, iconURL: message.author.avatarURL()})
.setImage(`${avatarURL}`)
.setColor("#3c5b6f")
.setFooter({ text: message.guild.name, iconURL: message.guild.iconURL()})
message.reply({ embeds: [embed], components: [row]})
  
}
}
