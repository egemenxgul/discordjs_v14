const {EmbedBuilder} = require("discord.js");

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ["kaccm", "kaç-cm", "kac-cm"],
  permLevel: 0,
  name: 'kaçcm',
  description: 'kaçcm',
  usage: 'kaçcm',
  cooldown: 5000,
  run: async (client, message, args) => {

  const cm = Math.floor(Math.random(100) * 100);

    const embed = new EmbedBuilder()
    .setDescription(`Senin ek bacak ${cm} cm çıktı`)
    .setColor("#0082ff")
    return message.channel.send({embeds : [embed]});

}
}
