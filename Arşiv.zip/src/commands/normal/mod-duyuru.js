const Discord = require("discord.js");
module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
  name: 'duyuru',
  description: 'duyuru',
  usage: 'duyuru',
  cooldown: 5000,
  run: async (client, message, args) => {
  if (!message.member.permissions.has("0x0000000000000020"))
    return message.reply("Yetersiz Yetki!");

  let csd = args[0];
  if (!csd) return message.reply("Lütfen bir duyuru metni yaz!");

  await message.delete();

  message.channel.send({
    embeds: [
      new Discord.EmbedBuilder()
        .setTitle("EgoBot | Duyuru Sistemi")
        .setColor(Discord.Colors.Blue)
        .setThumbnail(
          message.guild.iconURL({ dynamic: true }) ||
            client.user.displayAvatarURL({ dynamic: true })
        )
        .setDescription(args.slice(0).join(" "))
        .setTimestamp(),
    ],
  });
}
}