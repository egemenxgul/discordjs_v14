const Discord = require("discord.js");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['y-moderasyon', "h-moderasyon", "yardim-moderasyon", "help-moderasyon"],
  permLevel: 0,
  name: 'moderasyon',
  description: 'moderasyon',
  usage: 'moderasyon',
  cooldown: 5000,
  run: async (client, message, args) => {
  const Uptime = moment
    .duration(client.uptime)
    .format(" D [gün], H [saat], m [dakika], s [saniye]");
  const embed = new EmbedBuilder()
    .setAuthor({
      name: "EgoBot | Yardım Menüsü",
      iconURL: client.user.avatarURL(),
    })
    .setDescription(
      `**e!destek-yetkili** » Destek yetkili rolü ayarlarsınız.
      **e!ticket** » Belirttiğiniz kanalı destek açma kanalı yapar.
      **e!duyuru** » Yazdığınız mesajı duyuru biçminde yazar.
      **e!giriş-çıkış** » Giriş-çıkış yapan kullanıcıların mesajlarını belirtilen kanala atar.
      **e!giriş-çıkış kapat** » Giri-çıkış mesajlarını kapatır..
      **e!küfür-engel** » Küfür engelleme sistemini açar/kapatır.
      **e!mesajlog** » Silinen ve düzenlenen mesajların kayıt kanalını belirler.
      **e!mesajlog sil** » Mesaj kayıt sistemini siler/sıfırlar.
      **e!otorol** » Giriş yapan kullanıcılara otomatik rol verir.
      **e!otorol kapat** » Otorol sistemini kapatır.
      **e!reklam-engel** » Reklam engelleme sistemini açar/kapatır.
      **e!sil** » Belirttiğiniz kadar mesajı siler.`
    )
    .setFooter({
      text: `Yardım Menüsü`,
      iconURL: message.member.displayAvatarURL({ dynamic: true }),
    })
    .setColor("Blurple");
  message.reply({ embeds: [embed] });
}
};