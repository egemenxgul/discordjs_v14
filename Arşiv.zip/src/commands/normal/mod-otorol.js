const db = require("croxydb");
module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['otorol'],
  permLevel: 0,
  name: 'oto-rol',
  description: 'otorol',
  usage: 'otorol',
  cooldown: 5000,
  run: async (client, message, args) => {
  if (!message.member.permissions.has("0x0000000000000008"))
    return message
      .reply("Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!")
      .catch((e) => {});

  if (args[0] === "kapat" || args[0] === "sil") {
    let otorol = await db.get(`otorol.${message.guild.id}`);
    if (!otorol)
      return message
        .reply(
          "Otorol açık değil! Otorolü açmak için `e!otorol #log @role` yazabilirsiniz!"
        )
        .catch((e) => {});

    await db.delete(`otorol.${message.guild.id}`);
    return message.reply("Otorol başarıyla kapatıldı!").catch((e) => {});
  }

  let log = message.mentions.channels.first();
  if (!log)
    return message.reply("Lütfen bir kanal etiketleyin!").catch((e) => {});
  let rol = message.mentions.roles.first() || message.guild.roles.get(args[1]);
  if (!rol)
    return message.reply("Lütfen bir rol etiketleyin!").catch((e) => {});

  await db.set(`otorol.${message.guild.id}`, {
    log: log.id,
    rol: rol.id,
  });
  return message.reply("Otorol başarıyla açıldı!").catch((e) => {});
}
}
