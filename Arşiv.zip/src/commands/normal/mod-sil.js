const Discord = require("discord.js")

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['clear'],
  permLevel: 0,
  name: 'sil',
  description: 'sil',
  usage: 'sil',
  cooldown: 5000,
  run: async (client, message, args) => {

  if (!message.member.permissions.has("MANAGE_MESSAGES")) return message.reply(`"Mesajları Yönet" yetkin yok`);

  let miktar = args[0]
  if (!miktar) return message.reply("Bir miktar gir")
  message.channel.bulkDelete(miktar)
  return message.reply(`${miktar} tane mesaj sildim`).then(message => {
    setTimeout(() => message.delete(), 3000);
  });
e

}
}