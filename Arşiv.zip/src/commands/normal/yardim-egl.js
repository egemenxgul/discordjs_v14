const Discord = require("discord.js");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['y-eğlence', "h-fun", "yardim-eğlence", "help-fun", "fun", "eglence"],
  permLevel: 0,
  name: 'eğlence',
  description: 'eğlence',
  usage: 'eğlence',
  cooldown: 5000,
  run: async (client, message, args) => {
  const Uptime = moment
    .duration(client.uptime)
    .format(" D [gün], H [saat], m [dakika], s [saniye]");
  const embed = new EmbedBuilder()
    .setAuthor({
      name: "EgoBot | Yardım Menüsü",
      iconURL: client.user.avatarURL(),
    })
    .setDescription(
      `**e!1v1** » Belirttiğiniz kişileri kapıştırır.
      **e!kaçcm** » Ek bacağınızın kaç cm olduğunu söyler.
      **e!sarıl** » Belirttiğiniz kişiye sarılırsınız.
      **e!yazı-tura** » Yazı-tura atarsınız.`
    )
    .setFooter({
      text: `Yardım Menüsü`,
      iconURL: message.member.displayAvatarURL({ dynamic: true }),
    })
    .setColor("Blurple");
  message.reply({ embeds: [embed] });
}
};