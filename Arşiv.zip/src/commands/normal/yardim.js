const Discord = require("discord.js");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['y', "h", "yardim", "help"],
  permLevel: 0,
  name: 'yardım',
  description: 'yardım',
  usage: 'yardım',
  cooldown: 5000,
  run: async (client, message, args) => {
  const Uptime = moment
    .duration(client.uptime)
    .format(" D [gün], H [saat], m [dakika], s [saniye]");
  const embed = new EmbedBuilder()
    .setAuthor({
      name: "EgoBot | Yardım Menüsü",
      iconURL: client.user.avatarURL(),
    })
    .setDescription(
      `**e!destek** » Botun destek sunucusuna yönlendirir.
      **e!istatistik** » Botun istatistiklerini gösterir.
      **e!davet** » Botun davet bağlantısını gösterir.
      **e!eğlence** » Eğlence komutlarını listeler.
      **e!kullanıcı** » Kullanıcı komutlarını listeler.
      **e!moderasyon** » Moderasyon komutlarını listeler.`
    )
    .setFooter({
      text: `Yardım Menüsü`,
      iconURL: message.member.displayAvatarURL({ dynamic: true }),
    })
    .setColor("Blurple");
  message.reply({ embeds: [embed] });
}
};