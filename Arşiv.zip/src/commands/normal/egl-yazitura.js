const { EmbedBuilder } = require("discord.js");

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['yt', 'yazıtura'],
  permLevel: 0,
  name: 'yazı-tura',
  description: 'yazı-tura',
  usage: 'yazı-tura',
  cooldown: 5000,
  run: async (client, message, args) => {
  let yt = ["Yazı", "Tura", "Dik", "Para kayboldu"];
  let sonuç = yt[Math.floor(Math.random() * yt.length)];

  const embed = new EmbedBuilder()
    .setDescription(`**Sonuç:** ${sonuç}.`)
    .setColor("#0082ff");
  return message.channel.send({ embeds: [embed] });
}
}
