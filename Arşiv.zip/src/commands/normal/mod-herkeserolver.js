const {EmbedBuilder} = require("discord.js");

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ["herkese-rol-ver", "herkese-rolver", "herkeserol-ver"],
  permLevel: 0,
  name: 'herkeserolver',
  description: 'herkeserolver',
  usage: 'herkeserolver',
  cooldown: 5000,
  run: async (client, message, args) => {

    if(!message.member.permissions.has("ADMINISTRATOR")) return;
    var rol = message.mentions.roles.first()
    if(!rol) message.reply("Lütfen bir rol belirt.")
    message.guild.members.cache.forEach(arez => arez.roles.add(rol.id))
    return message.reply(`Herkese **${rol.id}** ID'li rol veriliyor. Bu işlemin süresi kullanıcı sayısına göre değişiklik göstermektedir.`)

}
}
