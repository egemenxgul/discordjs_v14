const db = require("croxydb");
module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['hoşgeldin', 'giriscikis', 'giris-cikis', 'girişçıkış'],
  permLevel: 0,
  name: 'giriş-çıkış',
  description: 'giriş-çıkış',
  usage: 'giriş-çıkış',
  cooldown: 5000,
  run: async (client, message, args) => {
  if (!message.member.permissions.has("0x0000000000000008"))
    return message
      .reply("Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!")
      .catch((e) => {});

  if (args[0] === "kapat" || args[0] === "sil") {
    let giriscikis = await db.get(`giriscikis.${message.guild.id}`);
    if (!giriscikis)
      return message
        .reply(
          "Giriş-çıkış mesajları açık değil! Mesajları açmak için `e!giriş-çıkış #log` yazabilirsiniz!"
        )
        .catch((e) => {});

    await db.delete(`giriscikis.${message.guild.id}`);
    return message.reply("Giriş-çıkış mesajları başarıyla kapatıldı!").catch((e) => {});
  }

  let gclog = message.mentions.channels.first();
  if (!gclog)
    return message.reply("Lütfen bir kanal etiketleyin!").catch((e) => {});

  await db.set(`giriscikis.${message.guild.id}`, {
    gclog: gclog.id,
  });
  return message.reply("Giriş-çıkış mesajları başarıyla açıldı!").catch((e) => {});
}
}
