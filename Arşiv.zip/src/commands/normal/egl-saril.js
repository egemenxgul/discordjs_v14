const Discord = require("discord.js");
module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['sarıl'],
  permLevel: 0,
  name: 'saril',
  description: 'sarıl',
  usage: 'sarıl',
  cooldown: 5000,
  run: async (client, message, args) => {
  let kisi = message.mentions.users.first() || client.users.cache.get(args[0]);
  if (!kisi) return message.reply("Kime sarılacağını yazman gerek 😥");

  if (kisi.id === message.author.id)
    return message.reply("Çok üzgünüm ama kendine sarılamazsın!");

  const embed = new Discord.EmbedBuilder()
    .setDescription(
      "<@" +
        kisi.id +
        ">, <@" +
        message.author.id +
        "> Sana sarılmak istiyor 💏 💘💗💖💕💟💞💝💓❤"
    )
    .setColor(Discord.Colors.Red)
    .setTimestamp()
    .setImage(
      "https://media.discordapp.net/attachments/737347015251460156/747779132422881290/tenor.gif?width=163&height=147"
    );
  message.channel.send({ content: "<@" + kisi.id + ">", embeds: [embed] });
}
}
