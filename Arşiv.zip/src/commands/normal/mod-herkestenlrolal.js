const {EmbedBuilder} = require("discord.js");

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ["herkesten-rol-al", "herkesten-rolal", "herkestenrol-al"],
  permLevel: 0,
  name: 'herkestenrolal',
  description: 'herkestenrolal',
  usage: 'herkestenrolal',
  cooldown: 5000,
  run: async (client, message, args) => {

    if(!message.member.permissions.has("ADMINISTRATOR")) return;
    var rol = message.mentions.roles.first()
    if(!rol) message.reply("Lütfen bir rol belirt.")
    message.guild.members.cache.forEach(arez => arez.roles.remove(rol.id))
    return message.reply(`Herkesten **${rol.id}** ID'li rol alınıyor. Bu işlemin süresi kullanıcı sayısına göre değişiklik göstermektedir.`)

}
}
