const { EmbedBuilder } = require("discord.js");
const db = require("croxydb");
const Discord = require("discord.js");

module.exports = {
  enabled: true,
  guildOnly: false,
  aliases: ['ticket-aç', "ticket-oluştur"],
  permLevel: 0,
  name: 'ticket',
  description: 'ticket',
  usage: 'ticket',
  cooldown: 5000,
  run: async (client, message, args) => {
  let mod = db.fetch(`ticketmod_${message.guild.id}`);
  if (!mod) return message.reply("Moderatör rolü ayarlanmamış!");
  let buton = args[0];
  if (!buton) return message.reply("Lütfen butonda yazıcak emojiyi girin!");

  const embed = new EmbedBuilder()
    .setTitle(client.user.username + " Destek Sistemi")
    .setDescription("Aşağıdaki butondan destek talebi oluşturabilirsin!")
    .setColor("Red");

  const row = new Discord.ActionRowBuilder().addComponents(
    new Discord.ButtonBuilder()
      .setEmoji(buton)
      .setStyle(Discord.ButtonStyle.Danger)
      .setCustomId("ticket")
  );

  message.channel.send({ embeds: [embed], components: [row] });
}
}
